Table of Content

What is it?
Program structure
Running
Licensing

What is it?
-----------

Movie Trailer Website is a website that users
use to see the movies that have been post on the
website. The website will display the list of movies
with the poster pictures and the title for each movie.
When the user click on a movie, there will a popup
to play the movie trailer for the movie that has been
clicked.

Propram Stucture
----------------

The project of Movie Trailer Website consists of three
main files. These files are following:

1. readme.txt: this read me file

1. media.py : is the file contains the Movie class that
              will store the movie detail information.

2. entertainment_center.py: is the main file of the 
              program. The file contains the contants
              of each movie that will list on the website
              and also it contains the statement that use
              to create the instance of each movie and 
              create the list of all movies in order
              to display on the website.

3. fresh_tomatoes.py: is the file contains the functions
              use to create the website and play the movie
              trailer.

Running
-------

Run the website by running the entertainment_center.py 
from the IDLE (Python GUI). 

Licensing
---------

- fresh_tomatoes.py is authorized to use in the project by
  Udacity.
- Movies trailer is the properties of youtube.com
- Movies image poster is the properties of imdb.com



