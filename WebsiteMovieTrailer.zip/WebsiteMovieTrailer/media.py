# This is Movies Class use to store the detail information about the movie

import webbrowser

class Movie():
        """The Movie Class
           Properties:
              - title : title of the movie
              - storyline : the description of the movie
              - poster_image_url : url to the poster image
              - trailer_youtube_url: url to the trailer of the movie in yourtube
           Method:
              - play_trailer() : use to play trailer of the movie 
        """
        
        def __init__(self , title , storyline , poster_image_url , trailer_youtube_url):
                self.title = title
                self.storyline=storyline
                self.poster_image_url = poster_image_url
                self.trailer_youtube_url = trailer_youtube_url
        def play_trailer(self):
                webbrowser.open(self.trailer_youtube_url)
		 
