import fresh_tomatoes # use to create the movie website
import media # the Movie class use to store movie information

#Toy Store Movie detail info
toystory_title="Toy Story"
toystory_storyline = ("A cowboy doll is profoundly threatened"
                      "and jealous when a new spaceman figure"
                      "supplants him as top toy in a boy's room.")
toystory_poster =    ("http://ia.media-imdb.com/images/M/MV5B"
                      "MDU2ZWJlMjktMTRhMy00ZTA5LWEzNDgtYmNmZT"
                      "EwZTViZWJkXkEyXkFqcGdeQXVyNDQ2OTk4MzI@."
                      "_V1_SY1000_SX670_AL_.jpg")
toystory_youtube_url="https://www.youtube.com/watch?v=KYz2wyBy3kc"

#Avata detail info
avata_title = "Avata"
avata_storyline =   ("A paraplegic marine dispatched to the "
                     "moon Pandora on a unique mission becomes "
                     "torn between following his orders and "
                     "protecting the world he feels is his home.")
avata_poster =      ("http://ia.media-imdb.com/images/M/MV5BM"
                     "TYwOTEwNjAzMl5BMl5BanBnXkFtZTcwODc5MTUw"
                     "Mw@@._V1_.jpg")
avata_youtube_url = "https://www.youtube.com/watch?v=d1_JBMrrYw8"

#Iron Man 3 tail info
ironman3_title = "Iron Man 3"
ironman3_storyline = ("When Tony Stark's world is torn apart "
                      "by a formidable terrorist called the "
                      "Mandarin, he starts an odyssey of "
                      "rebuilding and retribution.")
ironman3_poster =    ("http://ia.media-imdb.com/images/M/MV5BM"
                      "TkzMjEzMjY1M15BMl5BanBnXkFtZTcwNTMxOTYy"
                      "OQ@@._V1_SY1000_SX700_AL_.jpg")
ironman3_youtube_url = "https://www.youtube.com/watch?v=2CzoSeClcw0"

#Underworld detail info
underworld_title = "Underworld: Blood Wars (2016)"
underworld_storyline = ("Vampire death dealer, Selene "
                        "(Kate Beckinsale) fights to end the eternal"
                        "war between the Lycan clan and the Vampire "
                        "faction that betrayed her.")
underworld_poster = ("http://ia.media-imdb.com/images/M/MV5BMTU2N"
                     "zE3NTk2NF5BMl5BanBnXkFtZTgwNjk0NzA2ODE@._V1_"
                     "SY1000_SX675_AL_.jpg")
underworld_youtube_url = "https://www.youtube.com/watch?v=eScFp6RChu8"

#Transformer detail info
transformer_title = "Transformers (2007)"
transformer_storyline = ("An ancient struggle between two Cybertronian"
                         "races, the heroic Autobots and the evil "
                         "Decepticons, comes to Earth, with a clue to"
                         "the ultimate power held by a teenager.")
transformer_poster = ("http://ia.media-imdb.com/images/M/MV5BNDg1NTU2"
                      "OWEtM2UzYi00ZWRmLWEwMTktZWNjYWQ1NWM1OThjXkEyXk"
                      "FqcGdeQXVyMTQxNzMzNDI@._V1_SY1000_CR0,0,674,"
                      "1000_AL_.jpg")
transformer_youtube_url="https://www.youtube.com/watch?v=E-Sg_zJrDxc"

#Spider-Man (2002) detail info
spiderman_title = "Spider-Man (2002)"
spiderman_storyline = ("When bitten by a genetically modified spider, "
                       "a nerdy, shy, and awkward high school student "
                       "gains spider-like abilities that he eventually "
                       "must use to fight evil as a superhero after "
                       "tragedy befalls his family.")
spiderman_poster = ("http://ia.media-imdb.com/images/M/MV5BMzk3MTE5MDU"
                    "5NV5BMl5BanBnXkFtZTYwMjY3NTY3._V1_.jpg")
spiderman_youtube_url="https://www.youtube.com/watch?v=1bzqHbTD64w"

#Create Toy Story intance
toy_story = media.Movie(toystory_title,
                        toystory_storyline,
                        toystory_poster,
                        toystory_youtube_url)
#Create Avata instance
avata = media.Movie(avata_title,
                    avata_storyline,
                    avata_poster,
                    avata_youtube_url)
#Create Iron Man 3 instance
ironman3 = media.Movie(ironman3_title,
                       ironman3_storyline,
                       ironman3_poster,
                       ironman3_youtube_url)
#Create Underworld instance
underworld = media.Movie(underworld_title,
                         underworld_storyline,
                         underworld_poster,
                         underworld_youtube_url)
#Create Transformer instance
transformer = media.Movie(transformer_title,
                          transformer_storyline,
                          transformer_poster,
                          transformer_youtube_url)
#Create Spider Man instance
spiderman = media.Movie(spiderman_title,
                        spiderman_storyline,
                        spiderman_poster,
                        spiderman_youtube_url)

#Create array of movies instance into variable
movies = [toy_story,
          avata,
          ironman3,
          underworld,
          transformer,
          spiderman]
#Call open_movies_page function to create movie website
fresh_tomatoes.open_movies_page(movies)


print(media.Movie.__doc__)
